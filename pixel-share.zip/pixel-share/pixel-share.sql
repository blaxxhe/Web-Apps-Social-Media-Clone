-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 02:20 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pixel-share`
--

-- --------------------------------------------------------

--
-- Table structure for table `block_list`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 12:18 PM
--

CREATE TABLE `block_list` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blocked_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 12:12 PM
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment`, `created_at`) VALUES
(48, 16, 21, 'which location is this?', '2023-06-09 12:08:35'),
(49, 16, 21, 'how nice <3', '2023-06-09 12:08:49'),
(50, 17, 22, 'i like your trousers sml <3', '2023-06-09 12:12:26');

-- --------------------------------------------------------

--
-- Table structure for table `follow_list`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 12:15 PM
--

CREATE TABLE `follow_list` (
  `id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `follow_list`
--

INSERT INTO `follow_list` (`id`, `follower_id`, `user_id`) VALUES
(85, 13, 12),
(86, 14, 12),
(87, 14, 13),
(88, 13, 14),
(89, 12, 13),
(91, 12, 15),
(92, 12, 16),
(93, 12, 17),
(94, 13, 15),
(95, 13, 17),
(96, 13, 16),
(97, 17, 12),
(98, 17, 13),
(99, 17, 15),
(100, 17, 16),
(101, 16, 12),
(102, 16, 13),
(103, 16, 15),
(104, 16, 17),
(106, 15, 12),
(107, 15, 13),
(108, 15, 14),
(109, 15, 16),
(110, 15, 17),
(111, 18, 12),
(112, 18, 13),
(113, 18, 15),
(114, 18, 17),
(115, 12, 18),
(116, 19, 14),
(117, 19, 17),
(118, 19, 16),
(119, 20, 16),
(120, 20, 17),
(121, 20, 18),
(122, 21, 12),
(124, 22, 15),
(127, 22, 13);

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 12:12 PM
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `user_id`) VALUES
(91, 16, 13),
(92, 17, 15),
(93, 16, 15),
(94, 19, 12),
(95, 16, 21),
(96, 17, 22),
(97, 16, 22),
(98, 18, 22);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 12:16 PM
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `msg`, `read_status`, `created_at`) VALUES
(43, 22, 15, 'hi anjela! :>', 1, '2023-06-09 12:14:45'),
(44, 15, 22, 'hello karina, how are you? ', 0, '2023-06-09 12:16:24'),
(45, 15, 22, 'its been a long time tho', 0, '2023-06-09 12:16:32');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 12:17 PM
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `from_user_id` int(11) NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `post_id` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `to_user_id`, `message`, `created_at`, `from_user_id`, `read_status`, `post_id`) VALUES
(109, 12, 'started following you !', '2023-06-08 16:54:21', 13, 1, '0'),
(110, 12, 'started following you !', '2023-06-08 20:28:21', 14, 1, '0'),
(111, 13, 'started following you !', '2023-06-08 20:28:22', 14, 1, '0'),
(112, 14, 'started following you !', '2023-06-08 20:48:38', 13, 0, '0'),
(113, 13, 'started following you !', '2023-06-08 21:38:08', 12, 1, '0'),
(114, 14, 'started following you !', '2023-06-08 21:38:09', 12, 0, '0'),
(115, 15, 'started following you !', '2023-06-08 21:38:09', 12, 1, '0'),
(116, 16, 'started following you !', '2023-06-08 21:38:10', 12, 1, '0'),
(117, 17, 'started following you !', '2023-06-08 21:38:11', 12, 1, '0'),
(118, 12, 'blocked you', '2023-06-08 23:36:49', 12, 1, '0'),
(119, 12, 'Unblocked you !', '2023-06-08 23:36:51', 12, 1, '0'),
(120, 12, 'liked your post !', '2023-06-09 11:25:08', 13, 1, '16'),
(121, 15, 'started following you !', '2023-06-09 11:39:53', 13, 1, '0'),
(122, 17, 'started following you !', '2023-06-09 11:39:56', 13, 1, '0'),
(123, 16, 'started following you !', '2023-06-09 11:39:56', 13, 1, '0'),
(124, 12, 'started following you !', '2023-06-09 11:40:21', 17, 1, '0'),
(125, 13, 'started following you !', '2023-06-09 11:40:22', 17, 0, '0'),
(126, 15, 'started following you !', '2023-06-09 11:40:23', 17, 1, '0'),
(127, 16, 'started following you !', '2023-06-09 11:40:26', 17, 1, '0'),
(128, 12, 'started following you !', '2023-06-09 11:45:14', 16, 1, '0'),
(129, 13, 'started following you !', '2023-06-09 11:45:15', 16, 0, '0'),
(130, 15, 'started following you !', '2023-06-09 11:45:16', 16, 1, '0'),
(131, 17, 'started following you !', '2023-06-09 11:45:16', 16, 0, '0'),
(132, 14, 'started following you !', '2023-06-09 11:45:17', 16, 0, '0'),
(133, 14, 'Unfollowed you !', '2023-06-09 11:45:23', 16, 0, '0'),
(134, 12, 'started following you !', '2023-06-09 11:45:47', 15, 1, '0'),
(135, 13, 'started following you !', '2023-06-09 11:45:48', 15, 0, '0'),
(136, 14, 'started following you !', '2023-06-09 11:45:49', 15, 0, '0'),
(137, 16, 'started following you !', '2023-06-09 11:45:54', 15, 1, '0'),
(138, 17, 'started following you !', '2023-06-09 11:45:56', 15, 0, '0'),
(139, 13, 'liked your post !', '2023-06-09 11:47:02', 15, 0, '17'),
(140, 12, 'liked your post !', '2023-06-09 11:47:05', 15, 1, '16'),
(141, 12, 'started following you !', '2023-06-09 11:48:03', 18, 1, '0'),
(142, 13, 'started following you !', '2023-06-09 11:48:03', 18, 0, '0'),
(143, 15, 'started following you !', '2023-06-09 11:48:04', 18, 1, '0'),
(144, 17, 'started following you !', '2023-06-09 11:48:09', 18, 0, '0'),
(145, 18, 'started following you !', '2023-06-09 11:49:17', 12, 0, '0'),
(146, 14, 'Unfollowed you !', '2023-06-09 11:49:26', 12, 0, '0'),
(147, 18, 'liked your post !', '2023-06-09 11:49:39', 12, 0, '19'),
(148, 14, 'started following you !', '2023-06-09 12:01:34', 19, 0, '0'),
(149, 17, 'started following you !', '2023-06-09 12:01:37', 19, 0, '0'),
(150, 16, 'started following you !', '2023-06-09 12:01:39', 19, 0, '0'),
(151, 16, 'started following you !', '2023-06-09 12:02:21', 20, 0, '0'),
(152, 17, 'started following you !', '2023-06-09 12:02:28', 20, 0, '0'),
(153, 18, 'started following you !', '2023-06-09 12:02:43', 20, 0, '0'),
(154, 12, 'started following you !', '2023-06-09 12:08:06', 21, 1, '0'),
(155, 12, 'liked your post !', '2023-06-09 12:08:15', 21, 1, '16'),
(156, 12, 'commented on your post', '2023-06-09 12:08:35', 21, 1, '16'),
(157, 12, 'commented on your post', '2023-06-09 12:08:49', 21, 1, '16'),
(158, 12, 'started following you !', '2023-06-09 12:11:40', 22, 1, '0'),
(159, 15, 'started following you !', '2023-06-09 12:11:42', 22, 1, '0'),
(160, 13, 'started following you !', '2023-06-09 12:11:42', 22, 0, '0'),
(161, 13, 'liked your post !', '2023-06-09 12:12:00', 22, 0, '17'),
(162, 12, 'liked your post !', '2023-06-09 12:12:05', 22, 1, '16'),
(163, 13, 'commented on your post', '2023-06-09 12:12:26', 22, 0, '17'),
(164, 15, 'liked your post !', '2023-06-09 12:12:36', 22, 1, '18'),
(165, 13, 'Unfollowed you !', '2023-06-09 12:12:50', 22, 0, '0'),
(166, 12, 'blocked you', '2023-06-09 12:13:36', 22, 1, '0'),
(167, 12, 'started following you !', '2023-06-09 12:13:41', 22, 1, '0'),
(168, 12, 'Unfollowed you !', '2023-06-09 12:13:57', 22, 1, '0'),
(169, 13, 'started following you !', '2023-06-09 12:15:01', 22, 0, '0'),
(170, 22, 'blocked you', '2023-06-09 12:17:11', 22, 0, '0'),
(171, 22, 'Unblocked you !', '2023-06-09 12:17:13', 22, 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 11:49 AM
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_img` text NOT NULL,
  `post_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `post_img`, `post_text`, `created_at`) VALUES
(16, 12, '1686267538beach waves.jpg', 'beach waves', '2023-06-08 23:38:58'),
(17, 13, '1686310774ootd.jpg', 'ootd ♡', '2023-06-09 11:39:34'),
(18, 15, '1686311203moodboard.jpg', 'mood board as of today. ', '2023-06-09 11:46:43'),
(19, 18, '1686311342theweeknd.jpg', 'its the weeknd 💫', '2023-06-09 11:49:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Jun 08, 2023 at 03:16 PM
-- Last update: Jun 09, 2023 at 12:13 PM
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `profile_pic` text NOT NULL DEFAULT 'default_profile.jpg',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ac_status` int(11) NOT NULL COMMENT '0=not verified,1=active,2=blocked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `username`, `password`, `profile_pic`, `created_at`, `updated_at`, `ac_status`) VALUES
(12, 'blanche', 'balaba', 0, 'blanche.balaba@gmail.com', '_blaxxhe', '827ccb0eea8a706c4c34a16891f84e7b', '1686257357blanche.jpg', '2023-06-08 15:22:54', '2023-06-09 12:03:33', 0),
(13, 'thea', 'narca', 2, 'theanarca@gmail.com', 'theatots', '827ccb0eea8a706c4c34a16891f84e7b', '1686257331thea.jpg', '2023-06-08 16:06:48', '2023-06-08 20:48:51', 0),
(14, 'janna ', 'domingo', 2, 'domingojanna@gmail.com', 'jannatots', '827ccb0eea8a706c4c34a16891f84e7b', '1686257279janna.jpg', '2023-06-08 20:28:09', '2023-06-08 20:47:59', 0),
(15, 'anjela', 'gallarin', 2, 'anjelagallarin@gmail.com', 'anxxla', '827ccb0eea8a706c4c34a16891f84e7b', '1686311167anjela.jpg', '2023-06-08 21:07:55', '2023-06-09 11:46:07', 0),
(16, 'carl', 'melias', 1, 'carlmelias@gmail.com', 'carlosllagas', '827ccb0eea8a706c4c34a16891f84e7b', '16863120661686311133carl.jpg', '2023-06-08 21:08:26', '2023-06-09 12:01:06', 0),
(17, 'charles', 'raquedan', 1, 'charlezzz29@gmail.com', 'charleeees', '827ccb0eea8a706c4c34a16891f84e7b', '1686311092charles.jpg', '2023-06-08 21:09:05', '2023-06-09 11:44:52', 0),
(18, 'earl', 'canon', 1, 'earlcanon@gmail.com', 'earl_', '827ccb0eea8a706c4c34a16891f84e7b', '1686311303earl.jpg', '2023-06-08 21:09:25', '2023-06-09 11:48:23', 0),
(19, 'brian', 'moya', 1, 'brianmoya@gmail.com', 'briaan', '827ccb0eea8a706c4c34a16891f84e7b', '1686312121brian.jpg', '2023-06-08 21:10:08', '2023-06-09 12:02:01', 0),
(20, 'dave', 'lascano', 1, 'davelascano@gmail.com', 'lascano_', '827ccb0eea8a706c4c34a16891f84e7b', '1686312158dave.jpg', '2023-06-08 21:10:36', '2023-06-09 12:02:38', 0),
(21, 'jenny', 'fernandez', 2, 'blancheisme@yahoo.co.uk', 'jennifer', '827ccb0eea8a706c4c34a16891f84e7b', '1686312576jenny.jpg', '2023-06-09 12:07:46', '2023-06-09 12:09:36', 0),
(22, 'karina', 'charyl', 2, 'karinacharyl@gmail.com', 'charyl_', '827ccb0eea8a706c4c34a16891f84e7b', '1686312788karina.jpg', '2023-06-09 12:11:18', '2023-06-09 12:13:08', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `block_list`
--
ALTER TABLE `block_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follow_list`
--
ALTER TABLE `follow_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `block_list`
--
ALTER TABLE `block_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `follow_list`
--
ALTER TABLE `follow_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
